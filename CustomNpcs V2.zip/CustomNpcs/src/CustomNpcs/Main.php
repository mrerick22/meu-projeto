<?php

namespace CustomNpcs;

use pocketmine\entity\Entity;
use pocketmine\entity\EntityDataHelper as PMEntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\utils\TextFormat;
use pocketmine\world\World;
use pocketmine\entity\Human;
use pocketmine\entity\Skin;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\network\mcpe\protocol\ModalFormRequestPacket;
use pocketmine\network\mcpe\protocol\ModalFormResponsePacket;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\math\Vector3;
use pocketmine\entity\Location;
use pocketmine\event\world\WorldUnloadEvent;
use pocketmine\event\entity\EntitySpawnEvent;
use pocketmine\command\ConsoleCommandSender;

class Main extends PluginBase implements Listener {

    /** @var MyNPC[] */
    private array $npcs = [];
    private const SPAWN_FORM_ID = 12345678;
    private const EDIT_FORM_ID = 45678901;

    /** @var array<string, array> Armazena os dados das skins carregadas. */
    private array $skins = [];

    public function onEnable(): void {
        $this->getLogger()->info(TextFormat::GREEN . "Plugin CustomNpcs ativado com sucesso!");

        if (!is_dir($this->getDataFolder())) {
            mkdir($this->getDataFolder());
        }

        $this->loadSkins();

        EntityFactory::getInstance()->register(MyNPC::class, function(World $world, CompoundTag $nbt): MyNPC {
            return new MyNPC(PMEntityDataHelper::parseLocation($nbt, $world), $this->createDefaultSkin(), $nbt);
        }, ['MyNPC', 'mynpc'], EntityIds::PLAYER);
        
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }
    
    /**
     * Carrega todas as skins da pasta 'skins' do plugin.
     */
    private function loadSkins(): void {
        $skinDir = $this->getDataFolder() . "skins/";
        if (!is_dir($skinDir)) {
            mkdir($skinDir);
            $this->getLogger()->info(TextFormat::YELLOW . "Pasta 'skins' criada. Coloque seus arquivos .png de skin aqui (64x64 ou 64x32).");
            return;
        }

        $this->skins = [];
        $files = scandir($skinDir);
        foreach ($files as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) === 'png') {
                $skinName = pathinfo($file, PATHINFO_FILENAME);
                $skinPath = $skinDir . $file;
                
                $skinData = $this->processSkinFile($skinPath);
                if ($skinData !== null) {
                    $this->skins[$skinName] = $skinData;
                    $this->getLogger()->info(TextFormat::AQUA . "Skin '{$skinName}' carregada com sucesso.");
                } else {
                    $this->getLogger()->error(TextFormat::RED . "Falha ao processar arquivo de skin: {$file}");
                }
            }
        }
        $this->getLogger()->info(TextFormat::GREEN . count($this->skins) . " skins carregadas.");
    }

    /**
     * Processa um arquivo de skin PNG e converte para dados binários.
     */
    private function processSkinFile(string $filePath): ?array {
        if (!file_exists($filePath)) {
            return null;
        }

        $image = @imagecreatefrompng($filePath);
        if ($image === false) {
            return null;
        }

        $width = imagesx($image);
        $height = imagesy($image);

        // Verifica se é uma skin válida (64x64 ou 64x32)
        if (($width !== 64 || ($height !== 64 && $height !== 32))) {
            imagedestroy($image);
            return null;
        }

        $skinData = '';
        for ($y = 0; $y < $height; $y++) {
            for ($x = 0; $x < $width; $x++) {
                $rgba = imagecolorat($image, $x, $y);
                $a = (($rgba >> 24) & 0xFF);
                $r = (($rgba >> 16) & 0xFF);
                $g = (($rgba >> 8) & 0xFF);
                $b = ($rgba & 0xFF);
                $a = 255 - ($a * 2); // Converte alpha
                $skinData .= chr($r) . chr($g) . chr($b) . chr($a);
            }
        }

        imagedestroy($image);

        // Preenche com dados transparentes se necessário (para skins 64x32 -> 64x64)
        if ($height === 32) {
            $skinData .= str_repeat("\x00\x00\x00\x00", 64 * 32); // Preenche a parte inferior
        }

        return [
            'data' => $skinData,
            'width' => $width,
            'height' => $height === 32 ? 64 : $height // Normaliza para 64x64
        ];
    }
    
    public function onEntitySpawn(EntitySpawnEvent $event): void {
        $entity = $event->getEntity();
        if ($entity instanceof MyNPC) {
            $this->addNPC($entity);
            $this->getLogger()->info(TextFormat::AQUA . "NPC '{$entity->getCustomName()}' reconhecido e adicionado à lista.");
        }
    }
    
    public function onWorldUnload(WorldUnloadEvent $event): void {
        $worldName = $event->getWorld()->getFolderName();
        foreach ($this->npcs as $id => $npc) {
            if (!$npc->isClosed() && $npc->getWorld()->getFolderName() === $worldName) {
                unset($this->npcs[$id]);
            }
        }
    }

    /**
     * Detecta clique no NPC para executar comandos ou permitir combate
     */
    public function onEntityDamage(EntityDamageEvent $event): void {
        $entity = $event->getEntity();
        if (!$entity instanceof MyNPC) {
            return;
        }

        // Se for dano causado por jogador
        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            if ($damager instanceof Player) {
                
                // Se o NPC é pacífico, cancela o dano e executa comandos
                if (!$entity->canAttack()) {
                    $event->cancel();
                    
                    // Executa comandos do NPC
                    if (!empty($entity->getCommands())) {
                        $entity->executeCommands($damager);
                        $this->getLogger()->info(TextFormat::GREEN . "Jogador '{$damager->getName()}' interagiu com NPC '{$entity->getCustomName()}'");
                    } else {
                        $damager->sendMessage(TextFormat::YELLOW . "Este NPC não possui comandos configurados.");
                    }
                    return;
                }
                
                // Se o NPC é hostil, NÃO cancela o dano e define como alvo
                $entity->setTarget($damager);
                $this->getLogger()->info(TextFormat::YELLOW . "O NPC '{$entity->getCustomName()}' está agora atacando '{$damager->getName()}'.");
                
                // Atualizar o nametag com a vida atual
                $entity->updateNameTag();
            }
        } else {
            // Para outros tipos de dano em NPCs pacíficos, cancela
            if (!$entity->canAttack()) {
                $event->cancel();
            }
            // NPCs hostis podem receber dano de outras fontes também
        }
    }

    private function createDefaultSkin(): Skin {
        return new Skin(
            'Standard_Steve',
            str_repeat("\x00", 8192),
            '',
            'geometry.humanoid.custom'
        );
    }

    public function onDataPacketReceive(DataPacketReceiveEvent $event): void {
        $pk = $event->getPacket();
        $player = $event->getOrigin()->getPlayer();
        if (!$player instanceof Player) {
            return;
        }

        if ($pk instanceof ModalFormResponsePacket) {
            $formData = json_decode($pk->formData, true);
            if ($formData === null) {
                return;
            }

            switch ($pk->formId) {
                case self::SPAWN_FORM_ID:
                    $this->handleSpawnForm($player, $formData);
                    break;
                
                case self::EDIT_FORM_ID:
                    $this->handleEditForm($player, $formData);
                    break;
            }
        }
    }

    private function handleSpawnForm(Player $player, array $formData): void {
        $npcName = $formData[1] ?? "My NPC";
        $canAttack = $formData[2] ?? false;
        $health = (int)($formData[3] ?? 100);
        $attackDamage = (float)($formData[4] ?? 4.0);
        $skinIndex = $formData[5] ?? 0;
        $commands = $formData[6] ?? "";

        $skinOptions = ["(Skin Padrão Steve)"];
        $skinOptions = array_merge($skinOptions, array_keys($this->skins));
        $skinName = $skinOptions[$skinIndex] ?? null;

        $customId = mt_rand(1000, 9999999);
        
        $location = $player->getLocation();
        
        $nbt = CompoundTag::create()
            ->setTag("Pos", new ListTag([
                new DoubleTag($location->getX()),
                new DoubleTag($location->getY()),
                new DoubleTag($location->getZ())
            ]))
            ->setTag("Rotation", new ListTag([
                new FloatTag($location->getYaw()),
                new FloatTag($location->getPitch())
            ]))
            ->setLong("CustomId", $customId)
            ->setString("customName", $npcName)
            ->setByte("canAttack", $canAttack ? 1 : 0)
            ->setInt("customHealth", $health)
            ->setFloat("attackDamage", $attackDamage)
            ->setString("skinName", $skinName !== "(Skin Padrão Steve)" ? $skinName : "")
            ->setString("commands", $commands);
        
        $skin = $this->createSkinFromName($skinName);
        $npc = new MyNPC($location, $skin, $nbt);
        $npc->setNameTag($this->formatNameTag($npcName, $health, $canAttack));
        $npc->setNameTagVisible(true);
        $npc->spawnToAll();
        
        $player->sendMessage(TextFormat::GREEN . "NPC '{$npcName}' criado com sucesso! ID: {$customId}");
        $player->sendMessage(TextFormat::AQUA . "Para interagir com NPCs pacíficos, bata neles com a mão vazia!");
    }

    private function handleEditForm(Player $player, array $formData): void {
        if (count($formData) < 7) {
            $player->sendMessage(TextFormat::RED . "Dados do formulário inválidos.");
            return;
        }
    
        $npcId = (int)$formData[1];
        $newName = $formData[2] ?? "My NPC";
        $canAttack = $formData[3] ?? false;
        $health = (int)($formData[4] ?? 100);
        $attackDamage = (float)($formData[5] ?? 4.0);
        $skinIndex = $formData[6] ?? 0;
        $commands = $formData[7] ?? "";

        $skinOptions = ["(Skin Padrão Steve)"];
        $skinOptions = array_merge($skinOptions, array_keys($this->skins));
        $skinName = $skinOptions[$skinIndex] ?? null;
    
        $npc = $this->getNPCById($npcId);
        if ($npc === null) {
            $player->sendMessage(TextFormat::RED . "NPC com ID '{$npcId}' não encontrado.");
            return;
        }
    
        $npc->setCustomName($newName);
        $npc->setCanAttack($canAttack);
        $npc->setCustomHealth($health);
        $npc->setAttackDamage($attackDamage);
        $npc->setSkinName($skinName !== "(Skin Padrão Steve)" ? $skinName : "");
        $npc->setCommands($commands);
        
        // Aplica a nova skin
        $skin = $this->createSkinFromName($skinName);
        $npc->setSkin($skin);
        $npc->sendSkin();
        
        $npc->setNameTag($this->formatNameTag($newName, $health, $canAttack));
        
        $player->sendMessage(TextFormat::GREEN . "NPC '{$newName}' atualizado com sucesso!");
    }

    /**
     * Cria uma skin baseada no nome fornecido.
     */
    private function createSkinFromName(?string $skinName): Skin {
        if (empty($skinName) || $skinName === "(Skin Padrão Steve)" || !isset($this->skins[$skinName])) {
            // Retorna skin padrão do Steve
            return new Skin(
                'Standard_Steve',
                str_repeat("\x00", 8192),
                '',
                'geometry.humanoid.custom'
            );
        }

        $skinData = $this->skins[$skinName];
        return new Skin(
            'Custom_' . $skinName,
            $skinData['data'],
            '',
            'geometry.humanoid.custom'
        );
    }
    
    /**
     * Formata o nome e a barra de vida do NPC com visual melhorado.
     * A barra de vida só aparece para NPCs que podem atacar.
     */
    public function formatNameTag(string $name, int $health, bool $canAttack): string {
        $nameLine = TextFormat::BOLD . TextFormat::LIGHT_PURPLE . "❖ " . TextFormat::AQUA . $name . TextFormat::LIGHT_PURPLE . " ❖" . TextFormat::RESET;
        
        if ($canAttack) {
            $healthBar = $this->getHealthBarFormatted($health, $health);
            $healthStats = TextFormat::DARK_GRAY . "[" . TextFormat::WHITE . $health . TextFormat::DARK_GRAY . "/" . TextFormat::WHITE . $health . TextFormat::DARK_GRAY . "]";
            $statusLine = TextFormat::DARK_RED . "⚔ " . TextFormat::RED . TextFormat::BOLD . "HOSTIL" . TextFormat::RESET . TextFormat::DARK_RED . " ⚔";

            return $nameLine . "\n" . $healthBar . " " . $healthStats . "\n" . $statusLine;
        } else {
            $statusText = TextFormat::DARK_GREEN . "✓ " . TextFormat::GREEN . TextFormat::BOLD . "PACÍFICO" . TextFormat::RESET . TextFormat::DARK_GREEN . " ✓";
            $interactionHint = TextFormat::YELLOW . "▸ Clique para interagir ◂";
            return $nameLine . "\n" . $statusText . "\n" . $interactionHint;
        }
    }
    
    /**
     * Formata a barra de vida do NPC com visual aprimorado.
     * Usa gradientes de cores e bordas decorativas.
     */
    private function getHealthBarFormatted(int $currentHealth, int $maxHealth): string {
        $percentage = $maxHealth > 0 ? ($currentHealth / $maxHealth) : 0;
        $barLength = 20; // Barra mais longa para melhor precisão
        $filledBars = (int)round($percentage * $barLength);
        $emptyBars = $barLength - $filledBars;
        
        // Sistema de cores mais detalhado
        $healthColor = TextFormat::DARK_GREEN;
        $barSymbol = "■";
        
        if ($percentage > 0.75) {
            $healthColor = TextFormat::DARK_GREEN;
        } elseif ($percentage > 0.5) {
            $healthColor = TextFormat::GREEN;
        } elseif ($percentage > 0.25) {
            $healthColor = TextFormat::GOLD;
        } else {
            $healthColor = TextFormat::RED;
        }
        
        // Cria a barra com bordas
        $leftBorder = TextFormat::DARK_GRAY . "[";
        $rightBorder = TextFormat::DARK_GRAY . "]";
        $filledPart = $healthColor . str_repeat($barSymbol, $filledBars);
        $emptyPart = TextFormat::DARK_GRAY . str_repeat("■", $emptyBars);
        
        return $leftBorder . $filledPart . $emptyPart . $rightBorder;
    }

    public function getNPCById(int $id): ?MyNPC {
        return $this->npcs[$id] ?? null;
    }

    public function addNPC(MyNPC $npc): void {
        if (!isset($this->npcs[$npc->getCustomId()])) {
            $this->npcs[$npc->getCustomId()] = $npc;
        }
    }

    public function removeNPC(MyNPC $npc): void {
        $id = $npc->getCustomId();
        if (isset($this->npcs[$id])) {
            $npc->flagForDespawn();
            unset($this->npcs[$id]);
        }
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage(TextFormat::RED . "Este comando só pode ser usado por um jogador.");
            return false;
        }

        if ($command->getName() === "npc") {
            if (count($args) < 1) {
                $sender->sendMessage(TextFormat::YELLOW . "Uso: /npc <spawn|edit|remove|list>");
                return false;
            }

            switch (strtolower($args[0])) {
                case "spawn":
                    if (!$sender->hasPermission("customnpcs.command.npc.spawn")) {
                        $sender->sendMessage(TextFormat::RED . "Você não tem permissão para usar este comando.");
                        return false;
                    }
                    $this->sendCreateNPCForm($sender);
                    break;
                
                case "edit":
                    if (!$sender->hasPermission("customnpcs.command.npc.edit")) {
                        $sender->sendMessage(TextFormat::RED . "Você não tem permissão para usar este comando.");
                        return false;
                    }
                    
                    $nearestNPC = $this->getNearestNPC($sender, 10);
                    if ($nearestNPC !== null) {
                        $this->sendEditNPCForm($sender, $nearestNPC);
                    } else {
                        $sender->sendMessage(TextFormat::RED . "Nenhum NPC encontrado em um raio de 10 blocos.");
                    }
                    break;

                case "remove":
                    if (!$sender->hasPermission("customnpcs.command.npc.remove")) {
                        $sender->sendMessage(TextFormat::RED . "Você não tem permissão para usar este comando.");
                        return false;
                    }
                    
                    $nearestNPC = $this->getNearestNPC($sender, 10);
                    if ($nearestNPC !== null) {
                        $this->removeNPC($nearestNPC);
                        $sender->sendMessage(TextFormat::GREEN . "NPC '" . $nearestNPC->getCustomName() . "' removido com sucesso!");
                    } else {
                        $sender->sendMessage(TextFormat::RED . "Nenhum NPC encontrado em um raio de 10 blocos.");
                    }
                    break;

                case "list":
                    $count = count($this->npcs);
                    $sender->sendMessage(TextFormat::AQUA . "NPCs Ativos: {$count}");
                    if ($count > 0) {
                        foreach ($this->npcs as $npc) {
                            if (!$npc->isClosed()) {
                                $sender->sendMessage(TextFormat::GRAY . "- " . $npc->getCustomName() . " (ID: " . $npc->getCustomId() . ", Mundo: " . $npc->getWorld()->getFolderName() . ")");
                            }
                        }
                    }
                    break;

                default:
                    $sender->sendMessage(TextFormat::YELLOW . "Uso: /npc <spawn|edit|remove|list>");
                    return false;
            }
        }
        return true;
    }

    private function getNearestNPC(Player $player, float $maxDistance): ?MyNPC {
        $nearestNPC = null;
        $minDistance = $maxDistance;

        foreach ($this->npcs as $npc) {
            if ($npc->isClosed() || $npc->getWorld() !== $player->getWorld()) continue;
            
            $distance = $player->getPosition()->distance($npc->getPosition());
            if ($distance < $minDistance) {
                $minDistance = $distance;
                $nearestNPC = $npc;
            }
        }

        return $nearestNPC;
    }

    private function sendCreateNPCForm(Player $player): void {
        $skinOptions = ["(Skin Padrão Steve)"];
        $skinOptions = array_merge($skinOptions, array_keys($this->skins));

        $formData = [
            "type" => "custom_form",
            "title" => "Criar NPC Personalizado",
            "content" => [
                ["type" => "label", "text" => "Configure as propriedades do seu novo NPC.\n§eNPCs pacíficos executam comandos ao serem clicados."],
                ["type" => "input", "text" => "Nome do NPC", "default" => "Meu NPC"],
                ["type" => "toggle", "text" => "Pode Atacar Jogadores?", "default" => false],
                ["type" => "input", "text" => "Vida do NPC", "default" => "100"],
                ["type" => "input", "text" => "Dano de Ataque", "default" => "4.0"],
                ["type" => "dropdown", "text" => "Selecione a Skin", "options" => $skinOptions, "default" => 0],
                ["type" => "input", "text" => "Comandos (um por linha)", "default" => "", "placeholder" => "say Hello [player]\ngive [player] diamond"]
            ]
        ];
        
        $pk = new ModalFormRequestPacket();
        $pk->formId = self::SPAWN_FORM_ID;
        $pk->formData = json_encode($formData);
        $player->getNetworkSession()->sendDataPacket($pk);
    }
    
    private function sendEditNPCForm(Player $player, MyNPC $npc): void {
        $skinOptions = ["(Skin Padrão Steve)"];
        $skinOptions = array_merge($skinOptions, array_keys($this->skins));
        
        $defaultSkinIndex = 0;
        $currentSkinName = $npc->getSkinName();
        if (!empty($currentSkinName) && in_array($currentSkinName, array_keys($this->skins))) {
            $defaultSkinIndex = array_search($currentSkinName, array_keys($this->skins)) + 1; // +1 porque o primeiro é "(Skin Padrão Steve)"
        }

        $formData = [
            "type" => "custom_form",
            "title" => "Editar NPC: " . $npc->getCustomName(),
            "content" => [
                ["type" => "label", "text" => "Modifique as propriedades deste NPC.\n§eNPCs pacíficos executam comandos ao serem clicados."],
                ["type" => "input", "text" => "ID do NPC", "default" => (string)$npc->getCustomId(), "enabled" => false],
                ["type" => "input", "text" => "Novo Nome do NPC", "default" => $npc->getCustomName()],
                ["type" => "toggle", "text" => "Pode Atacar Jogadores?", "default" => $npc->canAttack()],
                ["type" => "input", "text" => "Nova Vida do NPC", "default" => (string)$npc->getCustomHealth()],
                ["type" => "input", "text" => "Dano de Ataque", "default" => (string)$npc->getAttackDamage()],
                ["type" => "dropdown", "text" => "Selecione a Skin", "options" => $skinOptions, "default" => $defaultSkinIndex],
                ["type" => "input", "text" => "Comandos (um por linha)", "default" => $npc->getCommands(), "placeholder" => "say Hello [player]\ngive [player] diamond"]
            ]
        ];
        
        $pk = new ModalFormRequestPacket();
        $pk->formId = self::EDIT_FORM_ID;
        $pk->formData = json_encode($formData);
        $player->getNetworkSession()->sendDataPacket($pk);
    }
}

class MyNPC extends Human {

    private int $customHealth;
    private bool $canAttack;
    private ?Entity $target = null;
    private string $customName;
    private int $customId;
    private int $lastAttackTick = 0;
    private float $attackDamage;
    private string $skinName = "";
    private string $commands = "";
    
    public function __construct(Location $location, Skin $skin, CompoundTag $nbt) {
        parent::__construct($location, $skin, $nbt);
    }

    protected function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);
        
        $this->customHealth = $nbt->getInt("customHealth", 100);
        $this->canAttack = $nbt->getByte("canAttack", 0) === 1;
        $this->customName = $nbt->getString("customName", "My NPC");
        $this->customId = (int)$nbt->getLong("CustomId", mt_rand(1000, 9999999));
        $this->attackDamage = $nbt->getFloat("attackDamage", 4.0);
        $this->skinName = $nbt->getString("skinName", "");
        $this->commands = $nbt->getString("commands", "");
        
        $this->setHealth($this->customHealth);
        $this->setMaxHealth($nbt->getInt("maxHealth", $this->customHealth));
    }
    
    public function saveNBT(): CompoundTag {
        $nbt = parent::saveNBT();
        
        $nbt->setByte("IsPersistent", 1);
        $nbt->setLong("CustomId", $this->customId);
        $nbt->setInt("customHealth", $this->customHealth);
        $nbt->setByte("canAttack", $this->canAttack ? 1 : 0);
        $nbt->setString("customName", $this->customName);
        $nbt->setString("World", $this->getWorld()->getFolderName());
        $nbt->setInt("maxHealth", $this->getMaxHealth());
        $nbt->setFloat("attackDamage", $this->attackDamage);
        $nbt->setString("skinName", $this->skinName);
        $nbt->setString("commands", $this->commands);
        
        return $nbt;
    }
    
    public function getCustomName(): string {
        return $this->customName;
    }
    
    public function setCustomName(string $name): void {
        $this->customName = $name;
    }

    public function getCustomHealth(): int {
        return $this->customHealth;
    }
    
    public function setCustomHealth(int $health): void {
        $this->customHealth = $health;
        $this->setMaxHealth($health);
        $this->setHealth($health);
    }

    public function canAttack(): bool {
        return $this->canAttack;
    }
    
    public function setCanAttack(bool $canAttack): void {
        $this->canAttack = $canAttack;
        
        if (!$canAttack && $this->target !== null) {
            $this->target = null;
        }
    }

    public function getAttackDamage(): float {
        return $this->attackDamage;
    }
    
    public function setAttackDamage(float $damage): void {
        $this->attackDamage = $damage;
    }

    public function getSkinName(): string {
        return $this->skinName;
    }
    
    public function setSkinName(string $skinName): void {
        $this->skinName = $skinName;
    }
    
    public function getCommands(): string {
        return $this->commands;
    }
    
    public function setCommands(string $commands): void {
        $this->commands = $commands;
    }

    public function getCustomId(): int {
        return $this->customId;
    }

    public function setTarget(?Entity $entity): void {
        $this->target = $entity;
    }

    public function getTarget(): ?Entity {
        return $this->target;
    }
    
    protected function entityBaseTick(int $tickDiff = 1): bool {
        $parentResult = parent::entityBaseTick($tickDiff);

        // Atualizar nametag periodicamente para mostrar vida atual
        if ($this->ticksLived % 20 === 0) { // A cada segundo
            $this->updateNameTag();
        }

        if ($this->target !== null && !$this->target->isClosed() && $this->canAttack) {
            $distance = $this->getPosition()->distance($this->target->getPosition());
            
            if ($distance < 2.5) {
                $this->attackTarget($this->target);
                $this->lookAt($this->target->getPosition());
            } elseif ($distance < 15) {
                $this->lookAt($this->target->getPosition());
                $this->moveToTarget($this->target);
            } else {
                $this->target = null;
            }
        }

        return $parentResult;
    }

    /**
     * Aplica dano ao alvo. Adicionado uma verificação para garantir que apenas
     * NPCs que podem atacar causem dano.
     */
    private function attackTarget(Entity $target): void {
        if (!$this->canAttack) {
            return;
        }

        $currentTick = $this->getWorld()->getServer()->getTick();
        if (!isset($this->lastAttackTick)) {
            $this->lastAttackTick = 0;
        }
        
        if ($currentTick - $this->lastAttackTick < 20) {
            return;
        }
        
        $this->lastAttackTick = $currentTick;
        
        if ($target instanceof Player) {
            $damage = new EntityDamageByEntityEvent(
                $this,
                $target,
                EntityDamageEvent::CAUSE_ENTITY_ATTACK,
                $this->attackDamage
            );
            
            $target->attack($damage);
            $target->sendMessage(TextFormat::RED . "Você foi atacado por " . $this->getCustomName() . "!");
            
            $direction = $target->getPosition()->subtract($this->getPosition()->getX(), 0, $this->getPosition()->getZ())->normalize();
            $knockback = $direction->multiply(0.5);
            $currentMotion = $target->getMotion();
            $target->setMotion(new Vector3(
                $currentMotion->getX() + $knockback->getX(),
                $currentMotion->getY() + 0.2,
                $currentMotion->getZ() + $knockback->getZ()
            ));
        }
    }
    
    /**
     * Move o NPC em direção ao alvo sem pular.
     * @param Entity $target O alvo para o qual o NPC deve se mover.
     */
    private function moveToTarget(Entity $target): void {
        $targetPos = $target->getPosition();
        $myPos = $this->getPosition();
        
        $diffX = $targetPos->getX() - $myPos->getX();
        $diffZ = $targetPos->getZ() - $myPos->getZ();
        
        $distance = sqrt($diffX * $diffX + $diffZ * $diffZ);
        
        if ($distance > 0) {
            $speedMultiplier = 0.2;
            $moveX = ($diffX / $distance) * $speedMultiplier;
            $moveZ = ($diffZ / $distance) * $speedMultiplier;
            
            // Define o movimento, mantendo o movimento vertical (Y) em zero
            $this->setMotion(new Vector3(
                $moveX,
                0, // Evita que o NPC pule
                $moveZ
            ));
        }
    }
    
    public function updateNameTag(): void {
        try {
            $server = $this->getWorld()->getServer();
            $plugin = $server->getPluginManager()->getPlugin("CustomNpcs") ?? 
                      $server->getPluginManager()->getPlugin("meuplugin");
                      
            if ($plugin instanceof Main) {
                $currentHealth = (int)ceil($this->getHealth());
                $this->setNameTag($plugin->formatNameTag($this->getCustomName(), $currentHealth, $this->canAttack));
            } else {
                $this->setBasicNameTag();
            }
        } catch (\Exception $e) {
            $this->setBasicNameTag();
            $this->getWorld()->getServer()->getLogger()->error("Erro ao atualizar name tag: " . $e->getMessage());
        }
    }
    
    /**
     * Define o nametag básico sem a dependência do plugin principal.
     * Versão melhorada com visual aprimorado.
     */
    private function setBasicNameTag(): void {
        $currentHealth = (int)ceil($this->getHealth());
        $maxHealth = $this->getMaxHealth();
        
        $nameLine = "§l§d❖ §b" . $this->getCustomName() . " §d❖§r";
        
        if ($this->canAttack) {
            $healthBar = $this->getAdvancedHealthBar($currentHealth, $maxHealth);
            $healthStats = "§8[§f{$currentHealth}§8/§f{$maxHealth}§8]";
            $statusLine = "§4⚔ §c§lHOSTIL§r §4⚔";
            
            $this->setNameTag($nameLine . "\n" . $healthBar . " " . $healthStats . "\n" . $statusLine);
        } else {
            $statusText = "§2✓ §a§lPACÍFICO§r §2✓";
            $interactionHint = "§e▸ Clique para interagir ◂";
            $this->setNameTag($nameLine . "\n" . $statusText . "\n" . $interactionHint);
        }
    }
    
    /**
     * Cria uma barra de vida avançada com cores graduais e bordas.
     * Versão melhorada para compatibilidade com o método básico.
     */
    private function getAdvancedHealthBar(int $currentHealth, int $maxHealth): string {
        $percentage = $maxHealth > 0 ? ($currentHealth / $maxHealth) : 0;
        $barLength = 20;
        $filledBars = (int)round($percentage * $barLength);
        $emptyBars = $barLength - $filledBars;
        
        // Sistema de cores detalhado
        $healthColor = "§2"; // Verde escuro
        if ($percentage > 0.75) {
            $healthColor = "§2"; // Verde escuro
        } elseif ($percentage > 0.5) {
            $healthColor = "§a"; // Verde
        } elseif ($percentage > 0.25) {
            $healthColor = "§6"; // Dourado
        } else {
            $healthColor = "§c"; // Vermelho
        }
        
        // Monta a barra com bordas
        $leftBorder = "§8[";
        $rightBorder = "§8]";
        $filledPart = $healthColor . str_repeat("■", $filledBars);
        $emptyPart = "§8" . str_repeat("■", $emptyBars);
        
        return $leftBorder . $filledPart . $emptyPart . $rightBorder;
    }

    /**
     * Executa os comandos do NPC quando chamado pela classe Main.
     * Tenta executar primeiro como consola e, se falhar, como o jogador.
     */
    public function executeCommands(Player $player): void {
        $server = $this->getWorld()->getServer();
        $server->getLogger()->info(TextFormat::AQUA . "Executando comandos do NPC '{$this->getCustomName()}' para jogador '{$player->getName()}'...");
        
        $commandLines = explode("\n", $this->getCommands());

        foreach ($commandLines as $command) {
            $command = trim($command);
            if (empty($command)) continue;
            
            // Substitui placeholders
            $command = str_replace(
                ["[player]", "[x]", "[y]", "[z]", "[world]", "[npc]"],
                [
                    $player->getName(),
                    (int)$player->getPosition()->getX(),
                    (int)$player->getPosition()->getY(),
                    (int)$player->getPosition()->getZ(),
                    $player->getWorld()->getFolderName(),
                    $this->getCustomName()
                ],
                $command
            );
            
            $server->getLogger()->info(TextFormat::GRAY . "Tentando executar comando: " . $command);
            
            $executed = false;
            
            // Tenta executar como a consola
            try {
                $consoleSender = ConsoleCommandSender::getInstance();
                $server->getCommandMap()->dispatch($consoleSender, $command);
                $server->getLogger()->info(TextFormat::GREEN . "Comando executado pela consola: " . $command);
                $executed = true;
            } catch (\Throwable $e) {
                // Se falhar, tenta como o jogador
                $server->getLogger()->warning("Falha na execução do comando pela consola. Tentando como jogador...");
                try {
                    $server->getCommandMap()->dispatch($player, $command);
                    $server->getLogger()->info(TextFormat::GREEN . "Comando executado pelo jogador: " . $command);
                    $executed = true;
                } catch (\Throwable $e2) {
                    // Se falhar de novo, regista o erro final
                    $server->getLogger()->error("Erro ao executar comando '$command': " . $e2->getMessage());
                    $player->sendMessage(TextFormat::RED . "Erro no comando: " . $command);
                    $executed = true; // Impede a mensagem final de 'não executado'
                }
            }
        }
        
        $player->sendMessage(TextFormat::GREEN . "§l" . $this->getCustomName() . "§r§a: Comandos processados!");
    }

    public function getName(): string {
        return "MyNPC";
    }

    public static function getNetworkTypeId(): string {
        return EntityIds::PLAYER;
    }
}