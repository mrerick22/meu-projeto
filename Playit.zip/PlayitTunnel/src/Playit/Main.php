<?php

declare(strict_types=1);

namespace Playit;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
use pocketmine\scheduler\ClosureTask;
use pocketmine\scheduler\TaskHandler;

class Main extends PluginBase {

    private $config;
    private $claimUrl = null;
    private $isRunning = false;
    private $processHandler = null;
    private $agentPid = null;
    private $logFile;

    public function onEnable(): void {
        $this->saveDefaultConfig();
        $this->config = $this->getConfig();
        
        if (!is_dir($this->getDataFolder())) {
            mkdir($this->getDataFolder(), 0755, true);
        }
        
        $this->logFile = $this->getDataFolder() . "playit.log";
        
        $this->getLogger()->info(TextFormat::GREEN . "PlayitPlugin habilitado!");
        
        if ($this->config->get("auto-start", false)) {
            $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function(): void {
                $this->startPlayit();
            }), 20);
        }
    }

    public function onDisable(): void {
        $this->stopPlayit();
        $this->getLogger()->info(TextFormat::RED . "PlayitPlugin desabilitado!");
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "playit") {
            if (count($args) === 0) {
                $this->displayStatus($sender);
                return true;
            }
            
            switch (strtolower($args[0])) {
                case "start":
                    if ($this->isRunning) {
                        $sender->sendMessage(TextFormat::RED . "Playit já está rodando!");
                    } else {
                        $sender->sendMessage(TextFormat::YELLOW . "Iniciando Playit...");
                        $this->startPlayit();
                    }
                    return true;
                    
                case "stop":
                    if (!$this->isRunning) {
                        $sender->sendMessage(TextFormat::RED . "Playit não está rodando!");
                    } else {
                        $sender->sendMessage(TextFormat::YELLOW . "Parando Playit...");
                        $this->stopPlayit();
                        $sender->sendMessage(TextFormat::GREEN . "Playit parado!");
                    }
                    return true;
                    
                case "restart":
                    $sender->sendMessage(TextFormat::YELLOW . "Reiniciando Playit...");
                    $this->stopPlayit();
                    $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function(): void {
                        $this->startPlayit();
                    }), 40);
                    return true;
                    
                case "status":
                    $this->displayStatus($sender);
                    return true;
                    
                case "claim":
                    if ($this->claimUrl) {
                        $sender->sendMessage(TextFormat::AQUA . "Link de Claim: " . TextFormat::WHITE . $this->claimUrl);
                        $sender->sendMessage(TextFormat::YELLOW . "Acesse este link para configurar seus túneis no site do Playit!");
                    } else {
                        $sender->sendMessage(TextFormat::RED . "Nenhum link de claim disponível. Inicie o Playit primeiro.");
                    }
                    return true;
                    
                case "logs":
                    $sender->sendMessage(TextFormat::YELLOW . "Últimas linhas do log:");
                    $logs = $this->getLastLogs(10);
                    foreach ($logs as $log) {
                        $sender->sendMessage(TextFormat::WHITE . $log);
                    }
                    return true;
                    
                default:
                    $sender->sendMessage(TextFormat::RED . "Uso: /playit <start|stop|restart|status|claim|logs>");
                    return true;
            }
        }
        return false;
    }

    private function startPlayit(): void {
        if ($this->isRunning) {
            return;
        }

        $playitPath = $this->getPlayitExecutable();
        if (!$playitPath) {
            $this->getLogger()->error("Executável do Playit não encontrado! Baixe em https://playit.gg/download e coloque na pasta do plugin.");
            return;
        }

        // Comando atual do Playit: inicia o agente
        $command = escapeshellcmd($playitPath);
        
        // Iniciar o Playit em background, redirecionando a saída para o arquivo de log
        $fullCommand = "nohup " . $command . " > " . escapeshellarg($this->logFile) . " 2>&1 & echo $!";
        
        $output = shell_exec($fullCommand);
        
        if ($output) {
            $this->agentPid = (int) trim($output);
            $this->isRunning = true;
            
            $this->getLogger()->info("Playit iniciado com PID: " . $this->agentPid);
            $this->getLogger()->info("Aguardando link de claim...");
            
            // Agendar tarefa para verificar o status e capturar o link de claim
            $this->processHandler = $this->getScheduler()->scheduleRepeatingTask(
                new ClosureTask(function(): void {
                    $this->checkPlayitStatus();
                }), 
                100 // Verificar a cada 5 segundos
            );
            
        } else {
            $this->getLogger()->error("Falha ao iniciar o Playit!");
        }
    }

    private function stopPlayit(): void {
        if ($this->processHandler !== null) {
            $this->processHandler->cancel();
            $this->processHandler = null;
        }

        if ($this->agentPid !== null) {
            // Parar o processo do Playit
            if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
                exec("taskkill /F /PID " . $this->agentPid);
            } else {
                // Primeiro tenta um sinal TERM, depois KILL se necessário
                exec("kill " . $this->agentPid . " 2>/dev/null");
                sleep(2);
                exec("kill -9 " . $this->agentPid . " 2>/dev/null");
            }
            $this->agentPid = null;
        }

        $this->isRunning = false;
        $this->claimUrl = null;
        
        $this->getLogger()->info("Playit parado.");
    }

    private function checkPlayitStatus(): void {
        // Verificar se o processo ainda está rodando
        if ($this->agentPid !== null) {
            if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
                $output = shell_exec("tasklist /FI \"PID eq " . $this->agentPid . "\"");
                if (strpos($output, "playit") === false) {
                    $this->getLogger()->error("Playit parou inesperadamente!");
                    $this->stopPlayit();
                    return;
                }
            } else {
                $result = shell_exec("ps -p " . $this->agentPid);
                if (strpos($result, (string) $this->agentPid) === false) {
                    $this->getLogger()->error("Playit parou inesperadamente!");
                    $this->stopPlayit();
                    return;
                }
            }
        }

        // Verificar o arquivo de log por updates
        if (!file_exists($this->logFile)) {
            return;
        }
        
        $logContent = file_get_contents($this->logFile);
        
        // Procurar por URL de claim
        if (preg_match('/https:\/\/[a-zA-Z0-9.-]+\/claim\/[a-zA-Z0-9]+/', $logContent, $matches)) {
            $this->claimUrl = $matches[0];
            $this->getLogger()->info("Link de claim detectado: " . $this->claimUrl);
            $this->broadcastClaimUrl();
        }
    }

    private function broadcastClaimUrl(): void {
        if (!$this->claimUrl) return;
        
        $message = TextFormat::GOLD . "=== PLAYIT ATIVO ===" . "\n" .
                  TextFormat::AQUA . "Link para claim: " . TextFormat::WHITE . $this->claimUrl . "\n" .
                  TextFormat::YELLOW . "Acesse este link para configurar seus túneis no site do Playit!" . "\n" .
                  TextFormat::GOLD . "==================";
        
        $this->getServer()->broadcastMessage($message);
    }

    private function displayStatus(CommandSender $sender): void {
        $sender->sendMessage(TextFormat::YELLOW . "=== PlayitPlugin Status ===");
        $sender->sendMessage(TextFormat::WHITE . "Status: " . ($this->isRunning ? TextFormat::GREEN . "Rodando" : TextFormat::RED . "Parado"));
        $sender->sendMessage(TextFormat::WHITE . "Porta do servidor: " . TextFormat::AQUA . $this->getServer()->getPort());
        
        if ($this->claimUrl) {
            $sender->sendMessage(TextFormat::WHITE . "Link de Claim: " . TextFormat::AQUA . $this->claimUrl);
            $sender->sendMessage(TextFormat::YELLOW . "Acesse este link para configurar seus túneis no site do Playit!");
        } else {
            $sender->sendMessage(TextFormat::WHITE . "Link de Claim: " . TextFormat::RED . "Não disponível");
        }
        
        $sender->sendMessage(TextFormat::GRAY . "Comandos: /playit start, /playit stop, /playit restart, /playit status, /playit claim, /playit logs");
    }

    private function getPlayitExecutable(): ?string {
        $possiblePaths = [];
        
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $possiblePaths = [
                $this->getDataFolder() . "playit.exe",
                getcwd() . DIRECTORY_SEPARATOR . "playit.exe",
                "C:\\Program Files\\Playit\\playit.exe"
            ];
        } else {
            $possiblePaths = [
                $this->getDataFolder() . "playit",
                getcwd() . DIRECTORY_SEPARATOR . "playit",
                "/usr/local/bin/playit",
                "/usr/bin/playit",
                "./playit"
            ];
        }
        
        foreach ($possiblePaths as $path) {
            if (file_exists($path) && is_executable($path)) {
                return $path;
            }
        }
        
        $which = strtoupper(substr(PHP_OS, 0, 3)) === 'WIN' ? 'where' : 'which';
        $output = shell_exec("$which playit");
        if ($output !== null && trim($output) !== '') {
            return trim($output);
        }
        
        return null;
    }

    private function getLastLogs(int $lines = 10): array {
        if (!file_exists($this->logFile)) {
            return ["Arquivo de log não encontrado."];
        }
        
        $content = file($this->logFile);
        if ($content === false) {
            return ["Erro ao ler o arquivo de log."];
        }
        
        return array_slice($content, -$lines);
    }
}
