<?php

namespace CustomNpcs;

use pocketmine\entity\Entity;
use pocketmine\entity\EntityDataHelper as PMEntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\utils\TextFormat;
use pocketmine\world\World;
use pocketmine\entity\Human;
use pocketmine\entity\Skin;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\network\mcpe\protocol\ModalFormRequestPacket;
use pocketmine\network\mcpe\protocol\ModalFormResponsePacket;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\math\Vector3;
use pocketmine\entity\Location;
use pocketmine\event\world\WorldLoadEvent;
use pocketmine\scheduler\ClosureTask;
use InvalidArgumentException;
use RuntimeException;

class Main extends PluginBase implements Listener {

    /** @var MyNPC[] */
    private array $npcs = [];
    private const SPAWN_FORM_ID = 12345678;
    private const INTERACT_FORM_ID = 87654321;
    private const EDIT_FORM_ID = 45678901;
    
    private array $npcData = [];

    public function onEnable(): void {
        $this->getLogger()->info(TextFormat::GREEN . "Enhanced NBT NPC Plugin enabled!");

        if (!is_dir($this->getDataFolder())) {
            mkdir($this->getDataFolder());
        }

        // Register custom NPC entity
        EntityFactory::getInstance()->register(MyNPC::class, function(World $world, CompoundTag $nbt): MyNPC {
            return new MyNPC(PMEntityDataHelper::parseLocation($nbt, $world), $this->createDefaultSkin(), $nbt);
        }, ['MyNPC', 'mynpc'], EntityIds::PLAYER);
        
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        
        // Load NPCs after all worlds are loaded
        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function(): void {
            $this->loadNPCs();
        }), 40); // 2 seconds delay
    }

    public function onDisable(): void {
        $this->getLogger()->info(TextFormat::RED . "Saving NPC data...");
        $this->saveNPCs();
    }

    private function createDefaultSkin(): Skin {
        return new Skin(
            'Standard_Biped_Steve',
            str_repeat("\x00", 8192), // 64x64 skin data
            '',
            'geometry.humanoid.custom'
        );
    }

    public function onWorldLoad(WorldLoadEvent $event): void {
        // Respawn NPCs when world loads
        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($event): void {
            $this->respawnNPCsInWorld($event->getWorld());
        }), 20);
    }

    private function respawnNPCsInWorld(World $world): void {
        foreach ($this->npcData as $data) {
            if ($data['world'] === $world->getFolderName()) {
                $this->spawnNPCFromData($data);
            }
        }
    }

    public function onDataPacketReceive(DataPacketReceiveEvent $event): void {
        $pk = $event->getPacket();
        $player = $event->getOrigin()->getPlayer();
        if (!$player instanceof Player) {
            return;
        }

        if ($pk instanceof ModalFormResponsePacket) {
            $formData = json_decode($pk->formData, true);
            if ($formData === null) {
                return;
            }

            switch ($pk->formId) {
                case self::SPAWN_FORM_ID:
                    $this->handleSpawnForm($player, $formData);
                    break;

                case self::INTERACT_FORM_ID:
                    $this->handleInteractForm($player, $formData);
                    break;
                
                case self::EDIT_FORM_ID:
                    $this->handleEditForm($player, $formData);
                    break;
            }
        }
    }

    private function handleSpawnForm(Player $player, array $formData): void {
        $npcName = $formData[1] ?? "My NPC";
        $canAttack = $formData[2] ?? false;
        $health = (int)($formData[3] ?? 100);
        $attackDamage = (float)($formData[4] ?? 4.0);
        $geometryName = $formData[5] ?? "geometry.humanoid.custom";
        $geometryData = $formData[6] ?? "";

        $nbt = $this->createNPCNBT(
            $player->getLocation(),
            $npcName,
            $canAttack,
            $health,
            $attackDamage,
            $geometryName,
            $geometryData
        );
        
        $npc = new MyNPC($player->getLocation(), $this->createDefaultSkin(), $nbt);
        $npc->setNameTag($this->formatNameTag($npcName, $health, $canAttack, $attackDamage));
        $npc->setNameTagVisible(true);
        $npc->spawnToAll();
        
        $this->addNPC($npc);
        $player->sendMessage(TextFormat::GREEN . "NPC '{$npcName}' spawned successfully!");
    }

    private function handleInteractForm(Player $player, $formData): void {
        $buttonId = $formData;
        switch ($buttonId) {
            case 0:
                $player->sendMessage(TextFormat::GREEN . "Hello " . $player->getName() . "! Welcome to my shop.");
                break;
            case 1:
                $player->sendMessage(TextFormat::AQUA . "Here's some useful information!");
                break;
            case 2:
                $player->sendMessage(TextFormat::RED . "Goodbye!");
                break;
        }
    }

    private function handleEditForm(Player $player, array $formData): void {
        if (count($formData) < 7) {
            $player->sendMessage(TextFormat::RED . "Invalid form data received.");
            return;
        }

        $npcId = (int)$formData[1];
        $newName = $formData[2] ?? "My NPC";
        $canAttack = $formData[3] ?? false;
        $health = (int)($formData[4] ?? 100);
        $attackDamage = (float)($formData[5] ?? 4.0);
        $geometryName = $formData[6] ?? "geometry.humanoid.custom";
        $geometryData = $formData[7] ?? "";

        $npc = $this->getNPCById($npcId);
        if ($npc === null) {
            $player->sendMessage(TextFormat::RED . "NPC not found.");
            return;
        }

        // Update NPC properties
        $npc->setCustomName($newName);
        $npc->setCanAttack($canAttack);
        $npc->setCustomHealth($health);
        $npc->setHealth($health);
        $npc->setAttackDamage($attackDamage);
        $npc->setGeometryName($geometryName);
        if (!empty($geometryData)) {
            $npc->setGeometryData($geometryData);
        }
        $npc->setNameTag($this->formatNameTag($newName, $health, $canAttack, $attackDamage));
        
        $this->updateNPCData($npc);
        $player->sendMessage(TextFormat::GREEN . "NPC '{$newName}' updated successfully!");
    }

    private function createNPCNBT(Location $location, string $name, bool $canAttack, int $health, float $attackDamage = 4.0, string $geometryName = "geometry.humanoid.custom", string $geometryData = ""): CompoundTag {
        $nbt = CompoundTag::create()
            ->setTag("Pos", new ListTag([
                new DoubleTag($location->getX()),
                new DoubleTag($location->getY()),
                new DoubleTag($location->getZ())
            ]))
            ->setTag("Rotation", new ListTag([
                new FloatTag($location->getYaw()),
                new FloatTag($location->getPitch())
            ]))
            ->setString("customName", $name)
            ->setByte("canAttack", $canAttack ? 1 : 0)
            ->setInt("customHealth", $health)
            ->setInt("maxHealth", $health)
            ->setFloat("attackDamage", $attackDamage)
            ->setString("geometryName", $geometryName)
            ->setString("geometryData", $geometryData)
            ->setString("World", $location->getWorld()->getFolderName())
            ->setByte("IsPersistent", 1)
            ->setLong("CustomId", mt_rand(1000, 9999999)); // Unique identifier

        return $nbt;
    }

    public function onEntityDamage(EntityDamageEvent $event): void {
        $entity = $event->getEntity();
        if (!$entity instanceof MyNPC) {
            return;
        }

        // Se o NPC não pode atacar (é pacífico), cancela todo o dano
        if (!$entity->canAttack()) {
            $event->cancel();
            $entity->setHealth($entity->getMaxHealth()); // Garante que a vida não diminua
            return;
        }

        // Se o NPC pode atacar, permite o dano
        if ($event instanceof EntityDamageByEntityEvent) {
            $attacker = $event->getDamager();
            if ($attacker instanceof Player) {
                $entity->setTarget($attacker);
                $attacker->sendMessage(TextFormat::YELLOW . "O NPC " . $entity->getCustomName() . " está te atacando!");
            }
        }

        // Para NPCs hostis, não cancela o evento
        // Agenda a atualização da nametag após o dano ser aplicado
        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($entity): void {
            if (!$entity->isClosed()) {
                $entity->updateNameTag();
                
                // Se a vida chegou a 0 ou menos, respawn o NPC com vida cheia
                if ($entity->getHealth() <= 0) {
                    $entity->setHealth($entity->getMaxHealth());
                    $entity->updateNameTag();
                    
                    // Remove o alvo para parar o combate
                    $entity->setTarget(null);
                    
                    // Opcional: remover o NPC permanentemente
                    // $this->removeNPC($entity);
                }
            }
        }), 1);
    }

    public function formatNameTag(string $name, int $health, bool $canAttack, float $attackDamage = 4.0): string {
        $status = $canAttack ? TextFormat::RED . "(Hostil)" : TextFormat::GREEN . "(Pacífico)";
        $damageInfo = $canAttack ? TextFormat::GRAY . " | Dano: " . TextFormat::WHITE . $attackDamage : "";
        return TextFormat::BOLD . $name . TextFormat::RESET . "\n" . 
               TextFormat::GRAY . "Vida: " . TextFormat::WHITE . $health . " " . $status . $damageInfo;
    }

    private function loadNPCs(): void {
        $filePath = $this->getDataFolder() . "npcs.json";
        if (!file_exists($filePath)) {
            return;
        }
    
        $jsonData = file_get_contents($filePath);
        $data = json_decode($jsonData, true);
    
        if ($data === null || !is_array($data)) {
            $this->getLogger()->error("Failed to load NPC data from JSON file.");
            return;
        }
    
        $this->npcData = $data;
        $loadedCount = 0;

        foreach ($data as $npcData) {
            if ($this->spawnNPCFromData($npcData)) {
                $loadedCount++;
            }
        }
    
        $this->getLogger()->info(TextFormat::AQUA . "{$loadedCount} NPCs loaded successfully!");
    }

    private function spawnNPCFromData(array $npcData): bool {
        $worldName = $npcData["world"] ?? "world";
        $world = $this->getServer()->getWorldManager()->getWorldByName($worldName);

        if ($world === null) {
            $this->getLogger()->warning("World '{$worldName}' not found for NPC '" . ($npcData["customName"] ?? "Unknown") . "'.");
            return false;
        }

        $location = new Location(
            $npcData["x"] ?? 0,
            $npcData["y"] ?? 0,
            $npcData["z"] ?? 0,
            $world,
            $npcData["yaw"] ?? 0,
            $npcData["pitch"] ?? 0
        );

        $nbt = $this->createNPCNBT(
            $location,
            $npcData["customName"] ?? "Unnamed NPC",
            $npcData["canAttack"] ?? false,
            $npcData["customHealth"] ?? 100,
            $npcData["attackDamage"] ?? 4.0,
            $npcData["geometryName"] ?? "geometry.humanoid.custom",
            $npcData["geometryData"] ?? ""
        );

        // Set the custom ID from saved data
        if (isset($npcData["customId"])) {
            $nbt->setLong("CustomId", $npcData["customId"]);
        }

        $npc = new MyNPC($location, $this->createDefaultSkin(), $nbt);
        $npc->setNameTag($this->formatNameTag(
            $npcData["customName"] ?? "Unnamed NPC",
            $npcData["customHealth"] ?? 100,
            $npcData["canAttack"] ?? false,
            $npcData["attackDamage"] ?? 4.0
        ));
        $npc->setNameTagVisible(true);
        $npc->spawnToAll();
        
        $this->npcs[$npc->getCustomId()] = $npc;
        return true;
    }

    private function saveNPCs(): void {
        $filePath = $this->getDataFolder() . "npcs.json";
        $data = [];

        foreach ($this->npcs as $npc) {
            if ($npc->isClosed()) continue;
            
            $data[] = [
                "customId" => $npc->getCustomId(),
                "customName" => $npc->getCustomName(),
                "x" => $npc->getPosition()->getX(),
                "y" => $npc->getPosition()->getY(),
                "z" => $npc->getPosition()->getZ(),
                "yaw" => $npc->getLocation()->getYaw(),
                "pitch" => $npc->getLocation()->getPitch(),
                "canAttack" => $npc->canAttack(),
                "customHealth" => $npc->getCustomHealth(),
                "attackDamage" => $npc->getAttackDamage(),
                "geometryName" => $npc->getGeometryName(),
                "geometryData" => $npc->getGeometryData(),
                "world" => $npc->getWorld()->getFolderName()
            ];
        }

        file_put_contents($filePath, json_encode($data, JSON_PRETTY_PRINT));
        $this->npcData = $data;
        
        $this->getLogger()->info(TextFormat::AQUA . count($data) . " NPCs saved successfully.");
    }

    public function getNPCById(int $id): ?MyNPC {
        return $this->npcs[$id] ?? null;
    }

    public function addNPC(MyNPC $npc): void {
        $this->npcs[$npc->getCustomId()] = $npc;
    }

    public function removeNPC(MyNPC $npc): void {
        $id = $npc->getCustomId();
        if (isset($this->npcs[$id])) {
            unset($this->npcs[$id]);
            $npc->flagForDespawn();
        }
    }

    private function updateNPCData(MyNPC $npc): void {
        $this->npcs[$npc->getCustomId()] = $npc;
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage(TextFormat::RED . "This command can only be used by a player.");
            return false;
        }

        if ($command->getName() === "npc") {
            if (count($args) < 1) {
                $sender->sendMessage(TextFormat::YELLOW . "Usage: /npc <spawn|edit|remove|list>");
                return false;
            }

            switch (strtolower($args[0])) {
                case "spawn":
                    if (!$sender->hasPermission("meuplugin.command.npc.spawn")) {
                        $sender->sendMessage(TextFormat::RED . "You don't have permission to use this command.");
                        return false;
                    }
                    $this->sendCreateNPCForm($sender);
                    break;
                
                case "edit":
                    if (!$sender->hasPermission("meuplugin.command.npc.edit")) {
                        $sender->sendMessage(TextFormat::RED . "You don't have permission to use this command.");
                        return false;
                    }
                    
                    $nearestNPC = $this->getNearestNPC($sender, 10);
                    if ($nearestNPC !== null) {
                        $this->sendEditNPCForm($sender, $nearestNPC);
                    } else {
                        $sender->sendMessage(TextFormat::RED . "No NPC found within 10 blocks.");
                    }
                    break;

                case "remove":
                    if (!$sender->hasPermission("meuplugin.command.npc.remove")) {
                        $sender->sendMessage(TextFormat::RED . "You don't have permission to use this command.");
                        return false;
                    }
                    
                    $nearestNPC = $this->getNearestNPC($sender, 10);
                    if ($nearestNPC !== null) {
                        $this->removeNPC($nearestNPC);
                        $sender->sendMessage(TextFormat::GREEN . "NPC '" . $nearestNPC->getCustomName() . "' removed successfully!");
                    } else {
                        $sender->sendMessage(TextFormat::RED . "No NPC found within 10 blocks.");
                    }
                    break;

                case "list":
                    $count = count($this->npcs);
                    $sender->sendMessage(TextFormat::AQUA . "Active NPCs: {$count}");
                    foreach ($this->npcs as $npc) {
                        $sender->sendMessage(TextFormat::GRAY . "- " . $npc->getCustomName() . " (ID: " . $npc->getCustomId() . ")");
                    }
                    break;

                default:
                    $sender->sendMessage(TextFormat::YELLOW . "Usage: /npc <spawn|edit|remove|list>");
                    return false;
            }
        }
        return true;
    }

    private function getNearestNPC(Player $player, float $maxDistance): ?MyNPC {
        $nearestNPC = null;
        $minDistance = $maxDistance;

        foreach ($this->npcs as $npc) {
            if ($npc->isClosed()) continue;
            
            $distance = $player->getPosition()->distance($npc->getPosition());
            if ($distance < $minDistance) {
                $minDistance = $distance;
                $nearestNPC = $npc;
            }
        }

        return $nearestNPC;
    }

    private function sendCreateNPCForm(Player $player): void {
        $formData = [
            "type" => "custom_form",
            "title" => "Criar NPC Personalizado",
            "content" => [
                ["type" => "label", "text" => "Configure as propriedades do seu novo NPC."],
                ["type" => "input", "text" => "Nome do NPC", "default" => "Meu NPC"],
                ["type" => "toggle", "text" => "Pode Atacar Jogadores?", "default" => false],
                ["type" => "input", "text" => "Vida do NPC", "default" => "100"],
                ["type" => "input", "text" => "Dano de Ataque", "default" => "4.0"],
                ["type" => "input", "text" => "Nome da Geometria (Blockbench)", "default" => "geometry.humanoid.custom"],
                ["type" => "input", "text" => "Dados da Geometria JSON (opcional)", "default" => ""]
            ]
        ];
        
        $pk = new ModalFormRequestPacket();
        $pk->formId = self::SPAWN_FORM_ID;
        $pk->formData = json_encode($formData);
        $player->getNetworkSession()->sendDataPacket($pk);
    }
    
    private function sendEditNPCForm(Player $player, MyNPC $npc): void {
        $formData = [
            "type" => "custom_form",
            "title" => "Editar NPC: " . $npc->getCustomName(),
            "content" => [
                ["type" => "label", "text" => "Modifique as propriedades deste NPC."],
                ["type" => "input", "text" => "ID do NPC", "default" => (string)$npc->getCustomId()],
                ["type" => "input", "text" => "Novo Nome do NPC", "default" => $npc->getCustomName()],
                ["type" => "toggle", "text" => "Pode Atacar Jogadores?", "default" => $npc->canAttack()],
                ["type" => "input", "text" => "Nova Vida do NPC", "default" => (string)$npc->getHealth()],
                ["type" => "input", "text" => "Dano de Ataque", "default" => (string)$npc->getAttackDamage()],
                ["type" => "input", "text" => "Nome da Geometria", "default" => $npc->getGeometryName()],
                ["type" => "input", "text" => "Dados da Geometria JSON", "default" => $npc->getGeometryData()]
            ]
        ];
        
        $pk = new ModalFormRequestPacket();
        $pk->formId = self::EDIT_FORM_ID;
        $pk->formData = json_encode($formData);
        $player->getNetworkSession()->sendDataPacket($pk);
    }

    public function sendNPCUI(Player $player): void {
        $data = [
            "type" => "form",
            "title" => "NPC Interaction",
            "content" => "Hello, " . $player->getName() . "! What would you like to do?",
            "buttons" => [
                ["text" => "Open Shop"],
                ["text" => "Get Information"],
                ["text" => "Exit"]
            ]
        ];

        $pk = new ModalFormRequestPacket();
        $pk->formId = self::INTERACT_FORM_ID;
        $pk->formData = json_encode($data);
        $player->getNetworkSession()->sendDataPacket($pk);
    }
}

class MyNPC extends Human {

    private int $customHealth;
    private bool $canAttack;
    private ?Entity $target = null;
    private string $customName;
    private int $customId;
    private int $lastAttackTick = 0;
    private float $attackDamage;
    private string $geometryName;
    private string $geometryData;
    
    public function __construct(Location $location, Skin $skin, CompoundTag $nbt) {
        parent::__construct($location, $skin, $nbt);
    }

    protected function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);
        
        $this->customHealth = $nbt->getInt("customHealth", 100);
        $this->canAttack = $nbt->getByte("canAttack", 0) === 1;
        $this->customName = $nbt->getString("customName", "My NPC");
        $this->customId = (int)$nbt->getLong("CustomId", mt_rand(1000, 9999999));
        $this->attackDamage = $nbt->getFloat("attackDamage", 4.0);
        $this->geometryName = $nbt->getString("geometryName", "geometry.humanoid.custom");
        $this->geometryData = $nbt->getString("geometryData", "");
        
        $this->setHealth($this->customHealth);
        $this->setMaxHealth($nbt->getInt("maxHealth", $this->customHealth));
        
        // Aplicar modelo personalizado se disponível
        if (!empty($this->geometryData)) {
            $this->applyCustomGeometry();
        }
    }
    
    public function saveNBT(): CompoundTag {
        $nbt = parent::saveNBT();
        
        $nbt->setByte("IsPersistent", 1);
        $nbt->setLong("CustomId", $this->customId);
        $nbt->setInt("customHealth", $this->customHealth);
        $nbt->setByte("canAttack", $this->canAttack ? 1 : 0);
        $nbt->setString("customName", $this->customName);
        $nbt->setString("World", $this->getWorld()->getFolderName());
        $nbt->setInt("maxHealth", $this->getMaxHealth());
        $nbt->setFloat("attackDamage", $this->attackDamage);
        $nbt->setString("geometryName", $this->geometryName);
        $nbt->setString("geometryData", $this->geometryData);
        
        return $nbt;
    }
    
    public function getCustomName(): string {
        return $this->customName;
    }
    
    public function setCustomName(string $name): void {
        $this->customName = $name;
    }

    public function getCustomHealth(): int {
        return $this->customHealth;
    }
    
    public function setCustomHealth(int $health): void {
        $this->customHealth = $health;
        $this->setMaxHealth($health);
        $this->setHealth($health);
    }

    public function canAttack(): bool {
        return $this->canAttack;
    }
    
    public function setCanAttack(bool $canAttack): void {
        $this->canAttack = $canAttack;
        
        // Se mudou para pacífico, remove o alvo atual
        if (!$canAttack && $this->target !== null) {
            $this->target = null;
        }
    }

    public function getAttackDamage(): float {
        return $this->attackDamage;
    }
    
    public function setAttackDamage(float $damage): void {
        $this->attackDamage = $damage;
    }

    public function getGeometryName(): string {
        return $this->geometryName;
    }
    
    public function setGeometryName(string $geometryName): void {
        $this->geometryName = $geometryName;
    }
    
    public function getGeometryData(): string {
        return $this->geometryData;
    }
    
    public function setGeometryData(string $geometryData): void {
        $this->geometryData = $geometryData;
        $this->applyCustomGeometry();
    }
    
    private function applyCustomGeometry(): void {
        if (!empty($this->geometryData)) {
            $skin = $this->getSkin();
            $newSkin = new Skin(
                $skin->getSkinId(),
                $skin->getSkinData(),
                $skin->getCapeData(),
                $this->geometryName,
                $this->geometryData
            );
            $this->setSkin($newSkin);
            $this->sendSkin();
        }
    }

    public function getCustomId(): int {
        return $this->customId;
    }

    public function setTarget(?Entity $entity): void {
        $this->target = $entity;
    }

    public function getTarget(): ?Entity {
        return $this->target;
    }
    
    protected function entityBaseTick(int $tickDiff = 1): bool {
        $parentResult = parent::entityBaseTick($tickDiff);

        // Sistema de combate melhorado
        if ($this->target !== null && !$this->target->isClosed() && $this->canAttack) {
            $distance = $this->getPosition()->distance($this->target->getPosition());
            
            if ($distance < 2.5) {
                // Ataque corpo a corpo
                $this->attackTarget($this->target);
                $this->lookAt($this->target->getPosition());
            } elseif ($distance < 15) {
                // Perseguir o alvo
                $this->lookAt($this->target->getPosition());
                $this->moveToTarget($this->target);
            } else {
                // Alvo muito longe, parar de perseguir
                $this->target = null;
            }
        }

        return $parentResult;
    }

    private function attackTarget(Entity $target): void {
        // Cooldown de ataque (ataca a cada 20 ticks = 1 segundo)
        $currentTick = $this->getWorld()->getServer()->getTick();
        if (!isset($this->lastAttackTick)) {
            $this->lastAttackTick = 0;
        }
        
        if ($currentTick - $this->lastAttackTick < 20) {
            return;
        }
        
        $this->lastAttackTick = $currentTick;
        
        // Criar evento de dano usando o método attack() da entidade
        if ($target instanceof Player) {
            $damage = new EntityDamageByEntityEvent(
                $this,
                $target,
                EntityDamageEvent::CAUSE_ENTITY_ATTACK,
                $this->attackDamage // Usa o dano personalizado
            );
            
            $target->attack($damage);
            $target->sendMessage(TextFormat::RED . "Você foi atacado por " . $this->getCustomName() . "!");
            
            // Efeito visual de knockback - corrigido
            $direction = $target->getPosition()->subtract($this->getPosition()->getX(), 0, $this->getPosition()->getZ())->normalize();
            $knockback = $direction->multiply(0.5);
            $currentMotion = $target->getMotion();
            $target->setMotion(new Vector3(
                $currentMotion->getX() + $knockback->getX(),
                $currentMotion->getY() + 0.2, // Pequeno impulso para cima
                $currentMotion->getZ() + $knockback->getZ()
            ));
        }
    }
    
    private function moveToTarget(Entity $target): void {
        $targetPos = $target->getPosition();
        $myPos = $this->getPosition();
        
        $diffX = $targetPos->getX() - $myPos->getX();
        $diffZ = $targetPos->getZ() - $myPos->getZ();
        
        $distance = sqrt($diffX * $diffX + $diffZ * $diffZ);
        
        if ($distance > 0) {
            $speedMultiplier = 0.2; // Velocidade de movimento
            $moveX = ($diffX / $distance) * $speedMultiplier;
            $moveZ = ($diffZ / $distance) * $speedMultiplier;
            
            $currentMotion = $this->getMotion();
            $this->setMotion(new Vector3(
                $currentMotion->getX() + $moveX,
                $currentMotion->getY(),
                $currentMotion->getZ() + $moveZ
            ));
        }
    }
    
    public function updateNameTag(): void {
        try {
            $server = $this->getWorld()->getServer();
            // Tenta primeiro o nome do plugin "CustomNpcs", depois "meuplugin"
            $plugin = $server->getPluginManager()->getPlugin("CustomNpcs") ?? 
                      $server->getPluginManager()->getPlugin("meuplugin");
                      
            if ($plugin instanceof Main) {
                $currentHealth = (int)ceil($this->getHealth()); // Arredonda para cima
                $this->setNameTag($plugin->formatNameTag($this->getCustomName(), $currentHealth, $this->canAttack, $this->attackDamage));
            } else {
                // Se não encontrou o plugin, usa formatação básica
                $this->setBasicNameTag();
            }
        } catch (\Exception $e) {
            // Se houver erro, usa formatação básica
            $this->setBasicNameTag();
        }
    }
    
    private function setBasicNameTag(): void {
        $currentHealth = (int)ceil($this->getHealth());
        $status = $this->canAttack ? "§c(Hostil)" : "§a(Pacífico)";
        $damageInfo = $this->canAttack ? "§7 | Dano: §f" . $this->attackDamage : "";
        $this->setNameTag("§l" . $this->getCustomName() . "§r\n§7Vida: §f" . $currentHealth . " " . $status . $damageInfo);
    }

    public function onInteract(Player $player, Vector3 $clickPos): bool {
        try {
            $server = $this->getWorld()->getServer();
            $plugin = $server->getPluginManager()->getPlugin("CustomNpcs") ?? 
                      $server->getPluginManager()->getPlugin("meuplugin");
                      
            if ($plugin instanceof Main) {
                $plugin->sendNPCUI($player);
            } else {
                $player->sendMessage("§cPlugin CustomNpcs não encontrado!");
            }
        } catch (\Exception $e) {
            $player->sendMessage("§cErro ao interagir com o NPC: " . $e->getMessage());
        }
        return parent::onInteract($player, $clickPos);
    }

    public function getName(): string {
        return "MyNPC";
    }

    public static function getNetworkTypeId(): string {
        return EntityIds::PLAYER;
    }
}
